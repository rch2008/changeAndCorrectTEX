# VBCCR
VB Common Controls Replacement Library (Replacement of the MS common controls)

This project is intended to replace the MS common controls for VB6.

http://www.vbforums.com/showthread.php?698563-CommonControls-(Replacement-of-the-MS-common-controls)
